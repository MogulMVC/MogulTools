<div id="MMainWindow">

	<div id="MHeaderPlaceholder"></div>
	<nav id="MHeader">
		<div class="MHeaderSpacer left"></div>
		<div class="MHeaderSpacer right"></div>

	</nav><!--MHeader-->
