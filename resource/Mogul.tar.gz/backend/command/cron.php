<?php
if (!defined('BACKEND_ROOT')) {
	header('Location: /error_404');
	exit ;
}

// Require all cron you want to run.
// require('myCronJob.php');
