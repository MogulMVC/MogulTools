<?php
if (!defined('BACKEND_ROOT')) {
	header('/error_404');
	exit ;
}
?>
</div><!--MMainWindow-->

<footer id="MFooter">
	<span>&copy; <?php echo date('Y') . ' ' . APPLICATION_COMPANY; ?></span>
	
	<!-- Your footer goes here -->
	
</footer>