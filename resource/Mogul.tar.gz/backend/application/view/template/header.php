<?php
if (!defined('BACKEND_ROOT')) {
	header('/error_404');
	exit ;
}
?>
<div id="MMainWindow">

	<div id="MHeaderPlaceholder"></div>
	<nav id="MHeader">
		<div class="MHeaderSpacer left"></div>
		<div class="MHeaderSpacer right"></div>

	</nav><!--MHeader-->
