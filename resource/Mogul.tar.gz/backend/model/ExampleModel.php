<?php

MLoad::php_application('core/db/MPDO');

class ExampleModel {

	public $table = 'example';

	public function create() {

	}

	public function read() {

	}

	public function update() {

	}

	public function delete() {

	}

}
