<?php

class MDate {

	public static function datetime() {
		return date('Y-m-d H:i:s');
	}

	public static function date() {
		return date('Y-m-d');
	}

}
