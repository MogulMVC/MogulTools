<?php
if (!defined('BACKEND_ROOT')) {
	header('Location: /error_404');
	exit ;
}

class MPath {

	/********** Models / VO Functions **********/

	public static function model() {

	}

	public static function vo() {

	}

	/********** View Functions **********/

	public static function view() {

	}

	/********** PHP Functions **********/

	public static function php_framework() {

	}

	public static function php_application() {

	}

	/********** JavaScript Functions **********/

	public static function js_framework() {

	}

	public static function js_application() {

	}

	/********** CSS Functions **********/

	public static function css_framework() {

	}

	public static function css_application() {

	}

	/********** Image Functions **********/

	public static function img_framework() {

	}

	public static function img_application() {

	}

	public static function icon_framework() {

	}

	/******* Controller Functions *******/

	public static function controller() {

	}

	public static function action() {

	}

	public static function api() {

	}

	/********** Other Functions **********/

	public static function command() {

	}

	public static function public_upload() {

	}

	public static function public_misc() {

	}

}
