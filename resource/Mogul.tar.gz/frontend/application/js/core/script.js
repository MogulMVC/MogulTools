/*
 * Put your site wide JavaScript here.
 * Then autoload it in with config/autoload.php
 */