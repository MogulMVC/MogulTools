<div id="MMainWindow">

	<div id="MHeaderPlaceholder"></div>
	<nav id="MHeader">
		<div class="MHeaderSpacer left"></div>
		<div class="MHeaderSpacer right"></div>
		
		<a href="/typography">Typography</a>
		<a href="/icons">Icons</a>
		<a href="/css_classes">CSS Classes</a>
		<a href="/js_classes">JavaScript Classes</a>
		<a href="/managers">Managers</a>

	</nav><!--MHeader-->
