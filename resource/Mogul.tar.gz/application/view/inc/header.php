<div id="MMainWindow">

	<div id="MHeaderPlaceholder"></div>
	<nav id="MHeader">
		<div class="MHeaderSpacer left"></div>
		<div class="MHeaderSpacer right"></div>
		
		<a href="/">Elements</a>
		<a href="/typography">Typography</a>
		<a href="/icons">Icons</a>

	</nav><!--MHeader-->
