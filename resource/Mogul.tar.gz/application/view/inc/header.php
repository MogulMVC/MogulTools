<div id="MMainWindow">

	<div id="MHeaderPlaceholder"></div>
	<header id="MHeader">

	</header><!--MHeader-->
