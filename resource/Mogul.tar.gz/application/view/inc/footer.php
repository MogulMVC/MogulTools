</div><!--MMainWindow-->

<footer>
  <!-- <span>&copy; <?php echo date("Y") . " " . APPLICATION_COMPANY; ?></span> -->
</footer>