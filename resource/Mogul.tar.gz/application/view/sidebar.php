<table>
	<tr>
		<td id="MSideBarContainer">
			<ul id="MSideBar" class="MSideBarLeft">
				
			</ul>
		</td>
		<td class="padding">
			
			<p class="MIntent">This is for working on the sidebar.</p>
			
		</td>
	</tr>
</table>