<div class="MContentSpacer"></div>
<div class="MContent840">
	<h1>Error 404</h1>
</div>

<?php echo $_SERVER['REQUEST_URI']; ?>