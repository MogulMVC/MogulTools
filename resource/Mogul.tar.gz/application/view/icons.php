<div class="MContent900">

	<h1>Icons</h1>

	<p class="MWidgetTitle">Arrows</p>

	<div style="position: relative">
		<span class="MIconArrorLeft"></span>
		<span class="MIconArrowRight"></span>
	</div>

	<br />
	<hr />
	<br />

	<p class="MWidgetTitle">Add</p>

	<span class="MIconAdd"></span>

	<br />
	<hr />
	<br />

	<p class="MWidgetTitle">Avatar</p>

	<span class="MAvatar"></span>
	<span class="MAvatar30x30"></span>
	<span class="MAvatar50x50"></span>
	<span class="MAvatar150x150"></span>
	<span class="MAvatar200x200"></span>
	<span class="MAvatar400x400"></span>

	<br />
	<hr />
	<br />

	<p class="MWidgetTitle">Background</p>

	<span class="MBackground"></span>

	<br />
	<hr />
	<br />

	<p class="MWidgetTitle">Close</p>

	<div style="position: relative">
		<span class="MIconClose"></span>
	</div>

	<br />
	<hr />
	<br />

	<p class="MWidgetTitle">Complete</p>

	<span class="MIconComplete"></span>
	<span class="MIconComplete30x30"></span>
	<span class="MIconComplete50x50"></span>
	<span class="MIconComplete150x150"></span>

	<br />
	<hr />
	<br />

	<p class="MWidgetTitle">Document</p>

	<span class="MIconDocument"></span>

	<br />
	<hr />
	<br />

	<p class="MWidgetTitle">Edit</p>

	<span class="MIconEdit"></span>

	<br />
	<hr />
	<br />

	<p class="MWidgetTitle">Embed</p>

	<span class="MIconEmbed"></span>
	<span class="MIconEmbed30x30"></span>
	<span class="MIconEmbed50x50"></span>
	<span class="MIconEmbed150x150"></span>

	<br />
	<hr />
	<br />

	<p class="MWidgetTitle">Facebook</p>

	<span class="MIconFacebook"></span>
	<span class="MIconFacebook30x30"></span>
	<span class="MIconFacebook50x50"></span>
	<span class="MIconFacebook150x150"></span>

	<br />
	<hr />
	<br />

	<p class="MWidgetTitle">Grid</p>

	<span class="MIconGrid"></span>

	<br />
	<hr />
	<br />

	<p class="MWidgetTitle">HD</p>

	<span class="MIconHD"></span>

	<br />
	<hr />
	<br />

	<p class="MWidgetTitle">List</p>

	<span class="MIconList"></span>

	<br />
	<hr />
	<br />

	<p class="MWidgetTitle">Loading</p>

	<span class="MIconLoadingBlack"></span>
	<span class="MIconLoadingBlack50x50"></span>
	<span class="MIconLoadingBlack150x150"></span>
	<span class="MIconLoadingWhite"></span>

	<br />
	<hr />
	<br />

	<p class="MWidgetTitle">Lock</p>

	<span class="MIconLock"></span>
	<span class="MIconLock64x64"></span>

	<br />
	<hr />
	<br />

	<p class="MWidgetTitle">Open Share</p>

	<span class="MIconOpenShare"></span>
	<span class="MIconOpenShare30x30"></span>
	<span class="MIconOpenShare50x50"></span>
	<span class="MIconOpenShare150x150"></span>

	<br />
	<hr />
	<br />

	<p class="MWidgetTitle">Poster</p>

	<span class="MIconPoster"></span>

	<br />
	<hr />
	<br />

	<p class="MWidgetTitle">Share This</p>

	<span class="MIconShareThis"></span>
	<span class="MIconShareThis30x30"></span>
	<span class="MIconShareThis50x50"></span>
	<span class="MIconShareThis150x150"></span>

	<br />
	<hr />
	<br />

	<p class="MWidgetTitle">Twitter</p>

	<span class="MIconTwitter"></span>
	<span class="MIconTwitter30x30"></span>
	<span class="MIconTwitter50x50"></span>
	<span class="MIconTwitter150x150"></span>

	<br />
	<hr />
	<br />

	<p class="MWidgetTitle">Warning</p>

	<span class="MIconWarning"></span>
	<span class="MIconWarning30x30"></span>
	<span class="MIconWarning50x50"></span>
	<span class="MIconWarning150x150"></span>

	<br /><br /><br /><br /><br /><br />

</div>