<table>
	<tr class="width_full">
		<td id="MSideBarContainer">
		<ul id="MSideBar" class="MSideBarLeft">

			<li>
				<input type="checkbox" />
				<label>Social</label>
			</li>

			<li>
				<input type="checkbox" />
				<label>Social</label>
			</li>

			<li>
				<input type="checkbox" />
				<label>Social</label>
			</li>

			<li>
				<input type="checkbox" />
				<label>Social</label>
			</li>

			<li>
				<input type="checkbox" />
				<label>Social</label>
			</li>

		</ul></td>

		<td class="width_full" style="padding: 30px">
			
		<section id="section_">
			<h1>Arrows</h1>

			<div class="MWidget" style="position: relative">
				<div class="MIconArrorLeft"></div>
				<div class="MIconArrowRight"></div>
			</div>
			
			<div class="MContentSpacer"></div>
			<div class="MContentSpacer"></div>
		</section>
		
		<section>
			<h1>Close</h1>
			<div class="MWidget" style="position: relative">
				<span class="MIconClose"></span>
			</div>
			
			<div class="MContentSpacer"></div>
			<div class="MContentSpacer"></div>
		</section>
		
		<section>
			<h1>Social</h1>
			
			<p class="MWidgetTitle">Facebook</p>
			
			<span class="MIconFacebook"></span>
			<span class="MIconFacebook30x30"></span>
			<span class="MIconFacebook50x50"></span>
			<span class="MIconFacebook150x150"></span>
			
			<div class="MContentSpacer"><hr /></div>
			
			<p class="MWidgetTitle">Twitter</p>
			
			<span class="MIconTwitter"></span>
			<span class="MIconTwitter30x30"></span>
			<span class="MIconTwitter50x50"></span>
			<span class="MIconTwitter150x150"></span>
			
		</section>

		<section>
			<h1>Avatar</h1>
			
			<span class="MAvatar"></span>
			<span class="MAvatar30x30"></span>
			<span class="MAvatar50x50"></span>
			<span class="MAvatar150x150"></span>
			<span class="MAvatar200x200"></span>
			<span class="MAvatar400x400"></span>
			
			<div class="MContentSpacer"></div>
			<div class="MContentSpacer"></div>
		</section>		

		<section>
			<h1>Complete</h1>
			
			<span class="MIconComplete"></span>
			<span class="MIconComplete30x30"></span>
			<span class="MIconComplete50x50"></span>
			<span class="MIconComplete150x150"></span>
			
			<div class="MContentSpacer"></div>
			<div class="MContentSpacer"></div>
		</section>

		<section>
			<h1>Embed</h1>
			
			<span class="MIconEmbed"></span>
			<span class="MIconEmbed30x30"></span>
			<span class="MIconEmbed50x50"></span>
			<span class="MIconEmbed150x150"></span>
						
			<div class="MContentSpacer"></div>
			<div class="MContentSpacer"></div>
		</section>

		<section>
			<h1>Loading</h1>
			
			<span class="MIconLoadingBlack"></span>
			<span class="MIconLoadingBlack50x50"></span>
			<span class="MIconLoadingBlack150x150"></span>
			<span class="MIconLoadingWhite"></span>
			
			<div class="MContentSpacer"></div>
			<div class="MContentSpacer"></div>
		</section>

		<section>
			<h1>Lock</h1>
			
			<span class="MIconLock"></span>
			<span class="MIconLock64x64"></span>
			
			<div class="MContentSpacer"></div>
			<div class="MContentSpacer"></div>
		</section>

		<section>
			<h1>Open Share</h1>
			
			<span class="MIconOpenShare"></span>
			<span class="MIconOpenShare30x30"></span>
			<span class="MIconOpenShare50x50"></span>
			<span class="MIconOpenShare150x150"></span>
			
			<div class="MContentSpacer"></div>
			<div class="MContentSpacer"></div>
		</section>

		<section>
			<h1>Share This</h1>
			
			<span class="MIconShareThis"></span>
			<span class="MIconShareThis30x30"></span>
			<span class="MIconShareThis50x50"></span>
			<span class="MIconShareThis150x150"></span>
			
			<div class="MContentSpacer"></div>
			<div class="MContentSpacer"></div>
		</section>

		<section>
			<h1>Warning</h1>
			
			<span class="MIconWarning"></span>
			<span class="MIconWarning30x30"></span>
			<span class="MIconWarning50x50"></span>
			<span class="MIconWarning150x150"></span>
			
			<div class="MContentSpacer"></div>
			<div class="MContentSpacer"></div>
		</section>
		
		<section>
			<h1>Misc</h1>
			
			<span class="MIconAdd"></span>
			<span class="MBackground"></span>
			<span class="MIconDocument"></span>
			<span class="MIconEdit"></span>
			<span class="MIconPoster"></span>
			<span class="MIconList"></span>
			<span class="MIconHD"></span>
			<span class="MIconGrid"></span>
			
			<div class="MContentSpacer"></div>
			<div class="MContentSpacer"></div>
		</section>
		
		</td>
	</tr>
</table>

