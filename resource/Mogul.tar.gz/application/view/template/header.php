<div id="MMainWindow">

	<div id="MHeaderPlaceholder"></div>
	<nav id="MHeader">
		<div class="MHeaderSpacer left"></div>
		<div class="MHeaderSpacer right"></div>

		<a href="/" id="MHeaderHome"><img src="<?php MLoad::img_application('header-home.png', 'echo'); ?>" /></a>
		<a href="/css_typography">Typography</a>
		<a href="/css_icons">Icons</a>
		<a href="/css_classes">CSS Classes</a>
		<a href="/js_classes">JavaScript Classes</a>
		<a href="/js_managers">JavaScript Managers</a>

	</nav><!--MHeader-->
