<?php 

class Test {

	function index() {
		MLoad::view('test.php');
	}

}
