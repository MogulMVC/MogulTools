<?php 

class Test {

	function index() {

	}

}
