<?php 

class Sidebar {

	function index() {
		MLoad::view('sidebar.php');
	}

}
