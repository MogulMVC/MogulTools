<?php 

class Main {

	function index() {
		MLoad::view('main.php');
	}

}
