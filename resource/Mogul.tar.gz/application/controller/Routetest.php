<?php

class Routetest {

	function index() {
		echo 'this is the route test';
	}

	function test() {
		echo 'this is a subpage';
	}

}
