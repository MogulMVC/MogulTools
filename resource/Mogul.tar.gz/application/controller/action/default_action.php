<?php

echo 'This is from the default action';
