<?php 

class Javascript_classes {

	function index() {
		$data['page_title'] = 'JavaScript Classes';
		MLoad::view('javascript_classes.php', $data);
	}

}
