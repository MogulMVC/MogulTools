<?php

MLoad::php_framework('core/db/MActiveRecord');

class ARTestModel extends MActiveRecord {

	static $table = 'testing1';

}
