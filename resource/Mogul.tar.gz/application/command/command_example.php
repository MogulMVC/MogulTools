<?php
if (!defined('SERVER_ROOT')) {
	header('/error_404');
	exit ;
}

echo 'Commands require a password for security.';
