<?php

echo 'Commands require a password for security.';
