<?php
if (!defined('SERVER_ROOT')) {
	header('/error_404');
	exit ;
}

// Require all cron you want to run.
// require('myCronJob.php');
