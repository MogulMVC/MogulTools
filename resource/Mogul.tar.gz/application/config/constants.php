<?php
if (!defined('SERVER_ROOT')) {header('/error_404');
	exit ;
}

// Example
// define('COST', 'value');
