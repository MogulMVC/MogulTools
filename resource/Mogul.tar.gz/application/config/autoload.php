<?php
if (!defined('SERVER_ROOT')) {header('/error_404');
	exit ;
}

$AUTOLOAD_PHP_FRAMEWORK = array();
$AUTOLOAD_PHP_APPLICATION = array();

$AUTOLOAD_CSS_FRAMEWORK = array();
$AUTOLOAD_CSS_APPLICATION = array();

$AUTOLOAD_JS_FRAMEWORK = array();
$AUTOLOAD_JS_APPLICATION = array();
?>