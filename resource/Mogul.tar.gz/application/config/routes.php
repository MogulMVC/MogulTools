<?php
if (!defined('SERVER_ROOT')) {header('/error_404');
	exit ;
}

// Any subpage to controller with function
// $ROUTE['page/*'] = 'controller/function';
//
// Any number to controller
// $ROUTE['page/#'] = 'controller/function';
//
// Page to controller
// $ROUTE['page/subpage'] = 'controller/function';
