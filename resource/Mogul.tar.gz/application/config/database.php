<?php
if (!defined('SERVER_ROOT')) {header('/error_404');
	exit ;
}

$DB_WARN = FALSE;
$DB_HOST = array();
$DB_USER = array();
$DB_PASS = array();
$DB_NAME = array();
?>