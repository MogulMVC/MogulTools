<?php
if (!defined('SERVER_ROOT')) {header('/error_404');
	exit ;
}

$DB_WARN = FALSE;
$DB_CONNECTION = array('connection1');
$DB_TYPE = array('mysql');
$DB_USER = array('alan1987_mglmvc');
$DB_PASS = array('z&(Ov*7q@hOl');
// $DB_HOST = array('localhost');
$DB_HOST = array('174.121.151.187');
$DB_NAME = array('alan1987_mglmvc');

