<?php
if (!defined('SERVER_ROOT')) {header('/error_404');
	exit ;
}

$GLOBALS['DB_CONNECTION'] = array('');
$GLOBALS['DB_TYPE'] = array('');
$GLOBALS['DB_USER'] = array('');
$GLOBALS['DB_PASS'] = array('');
$GLOBALS['DB_HOST'] = array('');
$GLOBALS['DB_NAME'] = array('');
