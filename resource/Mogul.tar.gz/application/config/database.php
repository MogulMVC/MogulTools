<?php
if (!defined('SERVER_ROOT')) {header('/error_404');
	exit ;
}

$GLOBALS['DB_CONNECTION'] = array('connection1', 'connection2');
$GLOBALS['DB_TYPE'] = array('mysql', 'mysql');
$GLOBALS['DB_USER'] = array('alan1987_mglmvc', 'alan1987_mglmvc');
$GLOBALS['DB_PASS'] = array('z&(Ov*7q@hOl', 'z&(Ov*7q@hOl');
// $GLOBALS['DB_HOST'] = array('localhost', 'localhost');
$GLOBALS['DB_HOST'] = array('174.121.151.187', '174.121.151.187');
$GLOBALS['DB_NAME'] = array('alan1987_mglmvc1', 'alan1987_mglmvc2');

