<?php

/*
 * Put your dynamic site wide CSS after the closing PHP tag.
 * To add PHP variables echo them in just like you would for HTML.
 * Autoload it with config/autoload.php.
 */

// This header must exist in this file
header('Content-type: text/css');
?>