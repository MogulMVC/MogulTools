<h3 class="red bold">An Error Occured</h3>
<img src="<?php echo MLoad::icon_framework('warning_150x150.png'); ?>" />
<br />
<p>
	Make sure to upload a valid image file under 2MB.
</p>
<br />
