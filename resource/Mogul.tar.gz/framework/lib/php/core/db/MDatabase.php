<?php
if (!defined('SERVER_ROOT')) {header('/error_404');
	exit ;
}

class MDatabase extends ActiveRecord\model {

	public static function create() {

	}

	public static function read($where) {

	}

	public static function delete($where) {

	}

}
